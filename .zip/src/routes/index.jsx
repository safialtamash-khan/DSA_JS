import React, { useContext, useEffect, useState } from 'react'
import { Navigate, Outlet, Route, Routes } from 'react-router-dom'
import Home from '../page/Home/Home'

import Login from '../page/Auth/Login/Login'
import { CommonContext } from '../context/CommonContext'
import { SessionContext } from '../context/SessionProvider'
import Layout from '../page/layout/layout'
import Counter from '../page/Counter/Counter'
// import SidebarLayout from '../page/layout/SampleLayout'



function PublicRoute() {
    return (
        <Outlet />
    )
}



function PrivateRoute({ auth }) {
    return (
        auth ? <Outlet /> : <Navigate to={'/'} />
    )
}

export default function Routing() {

  const { auth } = useContext(CommonContext)
  const { user } = useContext(SessionContext)
  // console.log('auth' , !!user);    
//   let isAuthenticated = false; // You can replace this with your actual auth check

const [isAuthenticated , setIsAuthenticated] = useState(false)


  useEffect(() => {
    setIsAuthenticated(!!user); // keep sync
  }, [user]);

  // console.log('isAuthenticated', isAuthenticated);
  

  return (
    <Routes>
      {/* Private Routes */}
      {isAuthenticated && (
        <Route element={<PrivateRoute auth={isAuthenticated} />}>
          {/* <Route path="/" element={<SidebarLayout />}> */}
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route  path='/counter'element={<Counter/>}/>
          </Route>
        </Route>
      )}

      {/* Public Routes */}
      {!isAuthenticated && (
        <Route element={<PublicRoute />}>
          <Route path="/" element={<Login />} />
        </Route>
      )}
    </Routes>
  );
}
