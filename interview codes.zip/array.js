// Find a pair with target sum in a sorted array
// Array: [1, 2, 3, 4, 5]
// Target Sum: 7

function findPair(array, target = 7) {
  try {
    console.log(array);
    let sum;

    let left = 0, right = array.length - 1
    console.log('left', left);
    console.log('right', right);


    while (left < right) {
      console.log('code in while loop');
      sum = array[left] + array[right];
      if (target === sum) {
        return { left, right }

      } else if (sum < target) {
        left++; // Increase the sum
      } else {
        right--; // Decrease the sum
      }
    }
    return -1
  } catch (error) {
    console.log('error', error);
  }
}
// console.log(findPair([1, 2, 3, 4, 5], 7))


//Remove duplicates from a sorted array


function findDuplicate(array) {
  if (array.length === 0) return 0


  let slow = 0;
  for (let i = 1; i < array.length; i++) {
    if (array[slow] !== array[i]) {
      slow++;
      array[slow] = array[i]
    }
  }
  return slow + 1
}

let array = [1, 2, 3, 3, 4, 5, 5]
// console.log(array.slice(0 , findDuplicate(array)));


// Reverse an array in-place

function reverseArray(array) {

  if (array.length === 0) return 0
  let left = 0; let right = array.length - 1

  while (left < right) {
    [array[left], array[right]] = [array[right], array[left]];
    left++
    right--
  }

  console.log(array);

}

// reverseArray([1, 2, 3, 4, 5])

// Check if a string is a palindrome

function isPalindrome(string) {
  let left = 0
  let right = string.length - 1

  while (left < right) {
    if (string[left] !== string[right]) {
      return false
    }
    left++
    right--
  }
  return true
}

// console.log(isPalindrome("mam"));   // true
// console.log(isPalindrome("madam")); // true
// console.log(isPalindrome("hello")); // false

// Input:  "hello"
// Output: "holle"

// Input:  "leetcode"
// Output: "leotcede"

function reverseVowels(string) {
  let vowels = ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'];
  let arr = string.split('')
  console.log(arr);
  let left = 0, right = arr.length - 0;

  while (left < right) {
    if (vowels.includes(arr[left]) && vowels.includes(arr[right])) {
      [arr[left], arr[right]] = [arr[right], arr[left]];
      left++
      right--
    } else if (!vowels.includes(arr[left])) {
      left++
    } else {
      right--
    }
  }
  return arr.join("");  // convert array back to string
}

// console.log(reverseVowels('hello'))


// Input:  "abcabcbb"
// Output: 3  (substring "abc")

function longestSubstring(string) {

  let set = new Set();
  let start = 0, end = 0, maxLength = 0;

  while (end < string.length) {
    if (!set.has(string[end])) {
      set.add(string[end])
      maxLength = Math.max(maxLength, set.size)
      end++
    } else {
      set.delete(string[start]);
      start++
    }
  }

  return maxLength
}

// console.log(longestSubstring("abcabcbb"))

// Input:  "abcabcbb"
function lengthOfLongestSubstring(s) {
  let set = new Set();
  let start = 0, maxLength = 0;
  // let end = 0;


  for (let end = 0; end < s.length; end++) {
    while (set.has(s[end])) {
      set.delete(s[start]);
      start++
    }
    set.add(s[end]);
    maxLength = Math.max(maxLength, end - start + 1)
  }
  return maxLength;
}

// console.log(lengthOfLongestSubstring("abcabcbb")); // 3


// 🔜 2. Longest Substring with At Most K Distinct Characters
// ➡️ New concept: Use a Map (or Object) to track frequencies
// ➡️ Purpose: Control max K unique characters in the current window
// Input: s = "eceba", k = 2  
// Output: 3  
// Explanation: "ece" has 2 distinct characters.


// 🔜 3. Longest Substring with Exactly K Distinct Characters
// (Same as above, but now we need exactly K instead of at most)



// 🔜 4. Longest Repeating Character Replacement
// ➡️ Given a string and an integer k, you can replace at most k characters to make the longest possible substring of the same letter.
// Input: s = "AABABBA", k = 1  
// Output: 4  
// Explanation: Replace the one 'B' → "AABA" → max length = 4



let unSortedArray = [1, 2, 4, 5, 6, 9, 8, 7, 3]

function findLargest(array, n) {
  let sortedArray = array.sort((a, b) => a - b)
  console.log(sortedArray[sortedArray.length - n]);
  return sortedArray[sortedArray.length - n]
}

// findLargest(unSortedArray, 3)


function findMissingNumber(array) {
      let n = array.length +1 
      console.log( n*(n+1)/2);
      
}

//  let exceptSum = (n * (n + 1) / 2);
console.log(findMissingNumber([1, 2, 4, 5, 6])); // 3