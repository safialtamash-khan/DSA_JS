console.log('web api');

// console.log(navigator);
// console.log(navigator?.platform);

// setInterval(()=>{
//     navigator?.geolocation?.watchPosition(
//         (position) => {
//           console.log('Updated Latitude:', position.coords.latitude);
//           console.log('Updated Longitude:', position.coords.longitude);
//         },
//         (error) => {
//           console.error('Error watching position:', error.message);
//         }
//       );
      
// },200);
 
//   const navigate = navigator.geolocation.getCurrentPosition((position)=>{
//     const { latitude , longitude } = position?.coords;
//     console.log(latitude);
//     console.log(longitude);
//   }, (error) => {
//     console.log(error);
//   });

//   console.log(navigate);

 