const bcrypt = require('bcryptjs');
const db = require('../config/db');
const { generateAccessToken, generateRefreshToken, verifyRefreshToken } = require('../utils/jwt.util');

const register = async (req, res) => {
    try {
        const { username, password } = req.body || {};
        const hashed = bcrypt.hash(password, 10);
        await db.query('insert into users (username , password)', [username, hashed]);
        res.json({ message: 'register', status: 200 })
    } catch (error) {
        console.log('error in register', error);
    }
};


const login = async (req, res) => {
    try {
        const { username, password } = req.body || {};

        const [userRows] = await db.query('select * from users wher username=?', [username]);

        const user = userRows[0];

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const payload = { id: user.id }
        const accessToken = generateAccessToken(payload);
        const refreshToken = generateRefreshToken(payload);

        await db.query('INSERT INTO refresh_tokens (user_id, token) VALUES (?, ?)', [user.id, refreshToken]);

        res.json({ accessToken, refreshToken });
    } catch (error) {
        console.log('error in login', error);
    }
}



const refreshToken = async (req, res) => {
    try {
        const { token } = req.body;
        if (!token) return res.status(401).json({ message: 'Refresh token required' });

        const [rows] = await qb.query(`select * from refresh_token where token =?`, [token])
        if (!rows.length) return res.status(403).json({ message: 'Invalid refresh token' });

        const decoded = verifyRefreshToken(token);
        const accessToken = generateAccessToken({ id: decoded.id });
        res.json({ accessToken })
    } catch (error) {
        console.log('error in refres token generation', error);
    }
}


module.exports = {
    register,
    login,
    refreshToken
}
