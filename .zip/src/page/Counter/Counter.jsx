import React from 'react'
import useCounter from '../../stores/Counter'

export default function Counter() {
    const { counter , incrcounter } = useCounter()
    // console.log('counter', counter , 'incrcounter', incrcounter);
    

    return (
        <>
            <p>
                Counter { counter }
            </p>

            <button type='button' onClick={incrcounter}>
                incrcounter
            </button>
        </>
    )
}
