const ENC_ALGO = "AES-GCM";
const ENC_PASS_ALGO = "PBKDF2";
const ENC_LENGTH = 256;
const HASH = "SHA-256";

const textEncoder = new TextEncoder();
const textDecoder = new TextDecoder();

export async function deriveKey(passphrase, salt) {
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    textEncoder.encode(passphrase),
    { name: ENC_PASS_ALGO },
    false,
    ["deriveKey"]
  );
  return crypto.subtle.deriveKey(
    {
      name: ENC_PASS_ALGO,
      salt: textEncoder.encode(salt),
      iterations: 100000,
      hash: HASH,
    },
    keyMaterial,
    { name: ENC_ALGO, length: ENC_LENGTH },
    false,
    ["encrypt", "decrypt"]
  );
}

export async function encryptData(key, data) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt(
    { name: ENC_ALGO, iv },
    key,
    textEncoder.encode(data)
  );
  return { iv: Array.from(iv), cipher: Array.from(new Uint8Array(encrypted)) };
}

export async function decryptData(key, encryptedData) {
  const iv = new Uint8Array(encryptedData.iv);
  const cipher = new Uint8Array(encryptedData.cipher);
  const decrypted = await crypto.subtle.decrypt(
    { name: ENC_ALGO, iv },
    key,
    cipher
  );
  return textDecoder.decode(decrypted);
}

export function saveLocal(name, data) {
  localStorage.setItem(name, JSON.stringify(data));
}

export function loadLocal(name) {
  const data = localStorage.getItem(name);
  return data ? JSON.parse(data) : null;
}
