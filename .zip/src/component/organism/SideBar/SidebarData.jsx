
import { AiFillHome } from "react-icons/ai";
import { RiArrowDownSFill } from "react-icons/ri";
import { RiArrowUpSFill } from "react-icons/ri";

import { FaUser } from "react-icons/fa";
import { FaMoneyBill } from "react-icons/fa";
import { AiFillFile } from "react-icons/ai";
import { AiOutlineFileDone } from "react-icons/ai";

import { FaBoxOpen } from "react-icons/fa";
import { FaCloudSun } from "react-icons/fa";
import { FaFileExcel } from "react-icons/fa";



export const SidebarData = [
  {
    title: 'Overview',
    icon: <AiFillHome />,
    iconClosed: <RiArrowDownSFill />,
    iconOpened: <RiArrowUpSFill />,
    subNav: [
      {
        title: 'Users',
        path: '/',
        icon: <FaUser />
      },
      {
        title: 'Revenue',
        path: '/globe',
        icon: <FaMoneyBill />
      }
    ]
  },
  {
    title: 'Reports',
    icon: <AiFillFile />,
    iconClosed: <RiArrowDownSFill />,
    iconOpened: <RiArrowUpSFill />,
    subNav: [
      {
        title: 'Reports 1',
        path: '/',
        icon: <AiOutlineFileDone />
      }
    ]
  },
  {
    title: 'Products',
    path: '/product',
    icon: <FaBoxOpen />
  },
  {
    title: 'Weather',
    path: '/weatherForecasts',
    icon: <FaCloudSun />
  },
  {
    title: 'Excel Preview',
    path: '/excelPreview',
    icon: <FaFileExcel />
  },
  {
    title: 'Counter',
    path: '/counter',
    icon: ''
  }

];
