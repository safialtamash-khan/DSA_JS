const userService = require('../services/userService')


const getAllUser = async (req, res) => {
    // services;
    try {
        let data = await userService.gettAllUser();
        res.json(data)
    } catch (error) {
        console.log('error', error);
    }
}

module.exports = {
    getAllUser
}