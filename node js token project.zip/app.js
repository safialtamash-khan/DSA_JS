const express = require('express');
require('dotenv').config();
const app = express();

const userRoute = require('./src/routes/userRoutes');
const authRoutes = require('./src/routes/auth.route');

app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoute);

app.use((err, req, res, next) => {
    res.status(500).json({ message: err.message });
});

module.exports = app;