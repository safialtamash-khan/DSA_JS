import React, { useEffect, useState } from 'react'
import './Layout.css'

import Header from '../../component/organism/Header/Header';
import { Outlet } from 'react-router-dom';
import Sidebar from '../../component/organism/SideBar/SideBar';


export default function Layout() {

    const [isSidebarOpen, setIsSidebarOpen] = useState(() => {
        return localStorage.getItem('sidebarOpen') === 'true';
    });
    const [submenuOpen, setSubmenuOpen] = useState({});

    useEffect(() => {
        localStorage.setItem('sidebarOpen', isSidebarOpen);
    }, [isSidebarOpen]);

    const toggleSidebar = () => setIsSidebarOpen((prev) => !prev);
    const toggleSubmenu = (index) => {
        setSubmenuOpen((prev) => ({
            ...prev,
            [index]: !prev[index],
        }));
    };





    return (
        <>
            <div className="page-wrapper">



                <div className='side-parent-container'>
                    <Sidebar
                        isSidebarOpen={isSidebarOpen}
                        submenuOpen={submenuOpen}
                        toggleSubmenu={toggleSubmenu}
                        toggleSidebar={toggleSidebar}
                    />
                </div>



                {/* Overlay (mobile only) */}
                {isSidebarOpen && (
                    <div className="overlay" onClick={toggleSidebar}></div>
                )}

                {/* Main Area */}
                <div className={`main-wrapper ${!isSidebarOpen ? 'expanded' : ''}`}>
                    {/* {!isSidebarOpen && (
                        <button className="open-btn" onClick={toggleSidebar}>☰</button>
                    )} */}

                    <Header />

                    {/* content pages */}
                    <div className="content">
                        <Outlet />
                    </div>
                </div>
            </div>
        </>
    )
}
