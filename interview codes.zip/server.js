var prompt = require('prompt');


prompt.start