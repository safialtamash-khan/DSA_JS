const jwt = require('jsonwebtoken');

const accessToken = process.env.ACCESS_TOKEN_SECRET;
const refreshToken = process.env.REFRESH_TOKEN_SECRET;

const generateAccessToken = (payload)=> jwt.sign(payload , accessToken, {expiresIn :'15m'});
const generateRefreshToken = (payload) => jwt.sign(payload , refreshToken , { expiresIn : "7d"});

const verifyAccessToken = token => jwt.verify(token , accessToken);
const verifyRefreshToken = token => jwt.verify(token , refreshToken);

module.exports = { 
    generateAccessToken,
    generateRefreshToken,
    verifyAccessToken,
    verifyRefreshToken
};