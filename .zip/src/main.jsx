import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { BrowserRouter } from 'react-router-dom'
import { MutationCache, QueryCache, QueryClient, QueryClientProvider } from '@tanstack/react-query'
import "bootstrap/dist/css/bootstrap.min.css";
import MyContextProvider from './context/CommonContext.jsx'
import { SessionProvider } from './context/SessionProvider.jsx'

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      cacheTime: 1000 * 60 * 10, // 10 minutes
      retry: 2, // Retry failed requests twice
      refetchOnWindowFocus: false, // Don't refetch when window regains focus
    },
    mutations: {
      retry: 1, // Retry failed mutations once
    },
  },

  queryCache: new QueryCache({
    onError: (error, query) => {
      console.error('Query error:', error);
    },
    onSuccess: (data, query) => {
      console.log('Query success:', data);
    },
  }),
  mutationCache: new MutationCache({
    onError: (error, variables, context, mutation) => {
      console.error('Mutation error:', error);
    },
    onSuccess: (data, variables, context, mutation) => {
      console.log('Mutation success:', data);
    },
  }),
})

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <SessionProvider>
      <MyContextProvider>
        <QueryClientProvider client={queryClient}>
          <BrowserRouter>
            <App />
          </BrowserRouter>
        </QueryClientProvider>
      </MyContextProvider>
    </SessionProvider>
  </StrictMode>,
)
