import { useState } from 'react'

import './App.css'
import Routing from './routes'


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <Routing />
    {/* <Layout/> */}
     
    </>
  )
}

export default App
