import React, { useContext } from 'react'
import { SessionContext } from '../../context/SessionProvider';

export default function Home() {
    const { user, logout } = useContext(SessionContext);

    // console.log('user', user);
    
    
    return (
        <div>
            <h1>Hello {user}</h1>
            <button onClick={logout}>Logout</button>
        </div>
    );
}
