const userModel = require("../model/userModel");


const gettAllUser = async () => {
    try {
        return await userModel.getAllUsers()
    } catch (error) {
        console.log('error', error);

    }
};


module.exports = { gettAllUser }