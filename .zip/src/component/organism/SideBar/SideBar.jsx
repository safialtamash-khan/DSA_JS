// import React from 'react'
// import './SideBar.css'

// export default function SideBar({
//     toggleSidebar,
//     isSidebarOpen
// }) {
//     return (
//         <>
//             <aside className={`sidebar ${isSidebarOpen ? 'open' : 'closed'}`}>
//                 <button className="close-btn" onClick={toggleSidebar}>✕</button>
//                 <div>Sidebar Content</div>
//             </aside>
//         </>
//     )
// }

    
import React from 'react';
import './Sidebar.css';
import { SidebarData } from './SidebarData';
import { Link, useLocation } from 'react-router-dom';

// Simple SVG icons for Hamburger and Close
const HamburgerIcon = () => (
  <svg width="28" height="28" viewBox="0 0 20 20"><rect y="4" width="20" height="2" rx="1"/><rect y="9" width="20" height="2" rx="1"/><rect y="14" width="20" height="2" rx="1"/></svg>
);
const CloseIcon = () => (
  <svg width="28" height="28" viewBox="0 0 20 20"><line x1="4" y1="4" x2="16" y2="16" stroke="white" strokeWidth="2"/><line x1="16" y1="4" x2="4" y2="16" stroke="white" strokeWidth="2"/></svg>
);

export default function Sidebar({
  isSidebarOpen,
  submenuOpen,
  toggleSubmenu,
  toggleSidebar
}) {
  const location = useLocation();

  return (
    <aside className={`sidebar ${isSidebarOpen ? 'open' : 'closed'}`}>
      <div className="toggle-btn" onClick={toggleSidebar} style={{ justifyContent: isSidebarOpen ? 'flex-end' : 'center' }}>
        {isSidebarOpen ? <CloseIcon /> : <HamburgerIcon/>}
      </div>
      <ul className="sidebar-list">
        {SidebarData.map((item, index) => {
          const isActive = location.pathname === item.path;
          return (
            <li key={index}>
              {item.subNav ? (
                <div
                  className={`menu-item ${isActive ? 'active' : ''}`}
                  onClick={() => toggleSubmenu(index)}
                >
                  <span className="icon">{item.icon}</span>
                  {isSidebarOpen && <span className="title">{item.title}</span>}
                  {isSidebarOpen && (
                    <span className="arrow">
                      {submenuOpen[index] ? item.iconOpened : item.iconClosed}
                    </span>
                  )}
                </div>
              ) : (
                <Link
                  to={item.path}
                  className={`menu-item menu-item-link ${isActive ? 'active' : ''}`}
                >
                  <span className="icon">{item.icon}</span>
                  {isSidebarOpen && <span className="title">{item.title}</span>}
                </Link>
              )}

              {/* Submenu */}
              {item.subNav && submenuOpen[index] && isSidebarOpen && (
                <ul className="submenu">
                  {item.subNav.map((subItem, subIndex) => (
                    <li key={subIndex}>
                      <Link
                        to={subItem.path}
                        className={`submenu-item ${location.pathname === subItem.path ? 'active' : ''}`}
                      >
                        <span className="title">{subItem.title}</span>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          );
        })}
      </ul>
    </aside>
  );
}
