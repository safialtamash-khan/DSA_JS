// SessionContext.jsx
import React, { createContext, useState, useEffect } from "react";
import {
    deriveKey,
    encryptData,
    decryptData,
    saveLocal,
    loadLocal,
} from "../utils/secureCrypto"

export const SessionContext = createContext();

export function SessionProvider({ children }) {
    const [user, setUser] = useState(null);

    useEffect(() => {
        async function restoreSession() {
            const token = localStorage.getItem("token");
            const encrypted = loadLocal("user_id");

            if (token && encrypted) {
                try {
                    const key = await deriveKey(token, import.meta.env.VITE_SALT);
                    const decryptedId = await decryptData(key, encrypted);

                    //   Fetch user details fresh (more secure)
                    //   const userData = await fetch(`/api/users/${decryptedId}`).then(res => res.json());
                    //   setUser(userData);

                    // console.log('decryptedId', decryptedId);

                    setUser(decryptedId); // ✅ Restore full user object
                } catch (err) {
                    console.error("Session restore failed:", err);
                    logout();
                }
            }
        }
        restoreSession();
    }, []);

    async function login(userId, token) {
        localStorage.setItem("token", token);

        const key = await deriveKey(token, import.meta.env.VITE_SALT);
        const encrypted = await encryptData(key, String(userId));

        saveLocal("user_id", encrypted);
        setUser(userId); // now user = userId
    }

    function logout() {
        localStorage.removeItem("token");
        localStorage.removeItem("user_id");
        setUser(null);
    }


    return (
        <SessionContext.Provider value={{ user, login, logout }}>
            {children}
        </SessionContext.Provider>
    );
}
