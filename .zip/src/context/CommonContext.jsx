import { createContext, useState } from "react";


export const CommonContext = createContext(null);


const MyContextProvider = ({ children }) => {
    const [data, setData] = useState(null);
    const [auth , setAuth] = useState(null)

    return (
        <>
            <CommonContext.Provider value={{ data, setData , auth , setAuth }}>
                {children}
            </CommonContext.Provider>
        </>
    )
};


export default MyContextProvider;