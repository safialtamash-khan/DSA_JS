const db = require('../config/db');

const getAllUsers = async () => {
    try {
        const [rows] = await db.query('select * from employees');
        return rows;
    } catch (error) {
        console.log('error', error);
    }
}

module.exports = {
    getAllUsers
};
