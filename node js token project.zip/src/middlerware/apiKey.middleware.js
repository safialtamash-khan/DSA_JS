const apiKey = process.env.API_KEYS;

module.exports = (req, res, next) => {
    try {
        const key = req.headers['x-api-key'];
        if (!key || !apiKey.includes(key)) return res.status(403).json({ message: 'Invalid API key' });
        next();
    } catch (error) {
        console.log('error', error);
    }
}