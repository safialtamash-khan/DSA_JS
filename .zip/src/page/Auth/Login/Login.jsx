import React, { useContext, useState } from "react";
import "./Login.css";
import data from './loginData.json';
import { CommonContext } from "../../../context/CommonContext";
// import { deriveKey, encryptData, saveToLocalStorage } from "../../../utils/secureCrypto";
import { SessionContext } from "../../../context/SessionProvider";


export default function Login() {

    const { setAuth } = useContext(CommonContext)
    const { login } = useContext(SessionContext);
    // console.log(context);

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPwd, setShowPwd] = useState(false);
    const [error, setError] = useState("");

    // console.log('data', data);


    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        if (!email || !password) {
            setError("Please fill in all fields.");
            return;
        }
        // if (!/\S+@\S+\.\S+/.test(email)) {
        //     setError("Enter a valid email address.");
        //     return;
        // }
        let userObj = data?.find(
            (item) => item.password === password || item.name === email
        );

        if (!userObj) {
            setError("Invalid credentials");
            return;
        }

        const token = "ajfhuwhfjvh74398279847yshdljksdhiugwqhdlc";
        await login(userObj.id, token);

        setAuth(true);
        // console.log(`Logged in as: ${isLogin}`);
    };

    return (
        <div className="container-fluid min-vh-100 d-flex align-items-center login-bg">
            <div className="row w-100 justify-content-center">
                <div className="col-11 col-sm-8 col-md-6 col-lg-4">
                    <form className="login-form shadow" onSubmit={handleSubmit}>
                        <h2 className="mb-4 text-center">Sign In</h2>
                        {error && (
                            <div className="alert alert-danger py-2">{error}</div>
                        )}
                        <div className="mb-3">
                            <label className="form-label">Email</label>
                            <input
                                className="form-control"
                                type="text"
                                placeholder="Enter email"
                                value={email}
                                onChange={e => setEmail(e.target.value)}
                                autoComplete="username"
                            />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Password</label>
                            <div className="input-group">
                                <input
                                    className="form-control"
                                    type={showPwd ? "text" : "password"}
                                    placeholder="Enter password"
                                    value={password}
                                    onChange={e => setPassword(e.target.value)}
                                    autoComplete="current-password"
                                />
                                <button
                                    type="button"
                                    className="btn btn-outline-secondary pwd-toggle"
                                    tabIndex={-1}
                                    onClick={() => setShowPwd((s) => !s)}
                                    title={showPwd ? "Hide Password" : "Show Password"}
                                >
                                    {showPwd ? "🙈" : "👁️"}
                                </button>
                            </div>
                        </div>
                        <button type="submit" className="btn btn-primary w-100">
                            Log In
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
}
